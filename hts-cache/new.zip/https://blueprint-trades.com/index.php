<!doctype html>
<html class="no-js" lang="en">
    
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Blueprint Trade</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
        <!-- Place favicon.ico in the root directory -->

        <!-- CSS here -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" href="assets/css/magnific-popup.css">
        <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
        <link rel="stylesheet" href="assets/css/flaticon.css">
        <link rel="stylesheet" href="assets/css/odometer.css">
        <link rel="stylesheet" href="assets/css/jarallax.css">
        <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
        <link rel="stylesheet" href="assets/css/slick.css">
        <link rel="stylesheet" href="assets/css/aos.css">
        <link rel="stylesheet" href="assets/css/default.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/responsive.css">
    <script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '811844c3d2ec284467afb513e84cfc9c30c9830c';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>
</head>
    <body>


        <!-- preloader -->
        <div id="preloader">
            <div id="loading-center">
                <div class="loader">
                    <div class="loader-outter"></div>
                    <div class="loader-inner"></div>
                </div>
            </div>
        </div>
        <!-- preloader-end -->

		<!-- Scroll-top -->
        <button class="scroll-top scroll-to-target" data-target="html">
            <i class="fas fa-angle-up"></i>
        </button>
        <!-- Scroll-top-end-->

        <!-- header-area -->
        <header id="sticky-header" class="transparent-header header-style-two">
            <div class="container custom-container">
                <div class="heder-top-wrap">
                    <div class="row align-items-center">
                        <div class="col-lg-7">
                            <div class="header-top-left">
                                <ul class="list-wrap">
                                    <li><i class="flaticon-location"></i>5357 Inglis St, Halifax, NS B3H 1J4, Canada</li>
                                    <li><i class="flaticon-location"></i>C/O Defries Weiss, 1 Bridge Lane, London, England, NW11 0EA</li>
                                    <li><i class="flaticon-mail"></i><a href="/cdn-cgi/l/email-protection#355451585c5b755759405045475c5b41184147545150461b565a58"><span class="__cf_email__" data-cfemail="7c1d181115123c1e1009190c0e15120851080e1d18190f521f1311">[email&#160;protected]</span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="header-top-right">
                                <div class="header-social">
                                    <ul class="list-wrap">
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                        <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                    </ul>
                                </div>
                                <div class="header-top-btn">
                                    <a href="contact.php"><i class="flaticon-briefcase"></i>Free Consulting</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="menu-area">
                    <div class="row">
                    <center>
<div id="google_translate_element"></div>
                        <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
                        <script type="text/javascript">
                            function googleTranslateElementInit() {
                                new google.translate.TranslateElement({ pageLanguage: 'en' }, 'google_translate_element');
                            }
                                </script>
                        <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                    </center>
                        <div class="col-12">
                        
                            <div class="mobile-nav-toggler"><i class="fas fa-bars"></i></div>
                            <div class="menu-wrap">
                            
                                <nav class="menu-nav">
                                
                                    <div class="logo">
                                        <a href="index.php"><img src="assets/img/logo/logo.png" alt="Logo"></a>
                                    </div>
                                    <div class="navbar-wrap main-menu d-none d-lg-flex">
                                        <ul class="navigation">
                                            <li class="active"><a href="index.php">Home</a></li>
                        
                        <li><a href="faq.html">FAQs</a></li>
                        <li><a href="privacy.html">Privacy Policy</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="register.php">Register</a></li>
                                        </ul>
                                    </div>
                                    <div class="header-action">
                                        <ul class="list-wrap">
                                            
                                            <li class="header-search"><a href="#"></a></li>
                                            <li class="offcanvas-menu">
                                                <a href="#" class="menu-tigger">
                                                    <span></span>
                                                    <span></span>
                                                    <span></span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>

                            <!-- Mobile Menu  -->
                            <div class="mobile-menu">
                                <nav class="menu-box">
                                    <div class="close-btn"><i class="fas fa-times"></i></div>
                                    <div class="nav-logo">
                                        <a href="index.php"><img src="assets/img/logo/logo.png" alt="Logo"></a>
                                    </div>
                                    
                                    <div class="menu-outer">
                                        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                                    </div>
                                    
                                </nav>
                            </div>
                            <div class="menu-backdrop"></div>
                            <!-- End Mobile Menu -->

                        </div>
                    </div>
                </div>
            </div>

            <!-- header-search -->
            <div class="search-popup-wrap" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="search-close">
                    <span><i class="fas fa-times"></i></span>
                </div>
                <div class="search-wrap text-center">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <h2 class="title">... Search Here ...</h2>
                                <div class="search-form">
                                    <form action="#">
                                        <input type="text" name="search" placeholder="Type keywords here">
                                        <button class="search-btn"><i class="fas fa-search"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-search-end -->

           

        </header>
        <!-- header-area-end -->


        <!-- main-area -->
        <main class="fix">

            <!-- banner-area -->
            <section class="banner-area-two banner-bg-two" data-background="assets/img/banner/h2_banner_bg.jpg">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="banner-content-two">
                                <span class="sub-title" data-aos="fade-up" data-aos-delay="0">We Are Expert In This Field</span>
                                <h2 class="title" data-aos="fade-up" data-aos-delay="300">Looking To Grow Your Investment Portfolio</h2>
                                <p data-aos="fade-up" data-aos-delay="500">Blueprint Trade helps you to analyze existing market data into a strategic asset and top-notch business insights to achieve an outstanding result.</p>
                                <div class="banner-btn">
                                    <a href="register.php" class="btn" data-aos="fade-right" data-aos-delay="700">Get Started</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="banner-img text-center">
                                <img src="assets/img/banner/h2_banner_img.png" alt="" data-aos="fade-left" data-aos-delay="400">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="banner-shape-wrap">
                    <img src="assets/img/banner/h2_banner_shape01.png" alt="">
                    <img src="assets/img/banner/h2_banner_shape02.png" alt="">
                    <img src="assets/img/banner/h2_banner_shape03.png" alt="" data-aos="zoom-in-up" data-aos-delay="800">
                </div>
            </section>
            <!-- banner-area-end -->
<div class="mgm" style="display: none;">
            <div class="txt" style="color: black;">An investor from  <b></b>just traded with <a href="javascript:void(0);" onclick="javascript:void(0);"></a></div>
        </div>
        <style>
            .mgm {
                border-radius: 7px;
                position: fixed;
                z-index: 90;
                bottom: 80px;
                left: 50px;
                background: #fff;
                padding: 10px 27px;
                box-shadow: 0 5px 13px 0 rgba(0,0,0,.3)
            }

                .mgm a {
                    font-weight: 700;
                    display: block;
                    color: #f2d516
                }

                    .mgm a, .mgm a:active {
                        transition: all .2s ease;
                        color: #f2d516
                    }
        </style>
        <script data-cfasync="false" src="cdn-cgi\scripts\5c5dd728\cloudflare-static\email-decode.min.js"></script>
        <script type="text/javascript">var listCountries = ['United Kingdom', 'USA', 'Germany', 'France', 'Italy', 'USA', 'Australia', 'Lesotho', 'Canada', 'Argentina', 'Saudi Arabia', 'Mexico', 'Kenya', 'Maldives', 'Venezuela', 'South Africa', 'Sweden', 'India', 'South Africa', 'Italy', 'Pakistan', 'United Kingdom', 'South Africa', 'Greece', 'Cuba', 'South Africa', 'Portugal', 'Austria', 'South Africa', 'Panama', 'USA', 'South Africa', 'Netherlands', 'Switzerland', 'Belgium', 'Israel', 'Cyprus']; var listPlans = ['$500', '$1500', '$1000', '$10,000', '$2000', '$3000', '$4000', '$600', '$700', '$2500']; interval = Math.floor(Math.random() * (40000 - 8000 + 1) + 8000); var run = setInterval(request, interval); function request() { clearInterval(run); interval = Math.floor(Math.random() * (40000 - 8000 + 1) + 8000); var country = listCountries[Math.floor(Math.random() * listCountries.length)]; var plan = listPlans[Math.floor(Math.random() * listPlans.length)]; var msg = 'An investor from  <b>' + country + '</b> just Withdrew <strong href="javascript:void(0);" onclick="javascript:void(0);">' + plan + ' </strong>'; $(".mgm .txt").html(msg); $(".mgm").stop(true).fadeIn(2); window.setTimeout(function () { $(".mgm").stop(true).fadeOut(100); }, 8000); run = setInterval(request, interval); }</script>
        
        <div class="mgm" style="display: none;">
            <div class="txt" style="color: black;">An investor from  <b></b>just traded with <a href="javascript:void(0);" onclick="javascript:void(0);"></a></div>
        </div>
        <style>
            .mgm {
                border-radius: 7px;
                position: fixed;
                z-index: 90;
                bottom: 80px;
                right: 50px;
                background: #fff;
                padding: 10px 27px;
                box-shadow: 0 5px 13px 0 rgba(0,0,0,.3)
            }

                .mgm a {
                    font-weight: 700;
                    display: block;
                    color: #f2d516
                }

                    .mgm a, .mgm a:active {
                        transition: all .2s ease;
                        color: #f2d516
                    }
        </style>
        <script data-cfasync="false" src="cdn-cgi\scripts\5c5dd728\cloudflare-static\email-decode.min.js"></script>
        <script type="text/javascript">var listCountries = ['London', 'Carlifornia', 'Germany', 'France', 'Italy', 'USA', 'Australia', 'Lesotho', 'Canada', 'Argentina', 'Saudi Arabia', 'Mexico', 'Kenya', 'Maldives', 'Venezuela', 'Soweto', 'Sweden', 'India', 'South Africa', 'Italy', 'Pakistan', 'United Kingdom', 'South Africa', 'Greece', 'Cuba', 'South Africa', 'Delhi', 'Austria', 'South Africa', 'Panama', 'USA', 'South Africa', 'Netherlands', 'Switzerland', 'Belgium', 'Israel', 'Cyprus']; var listPlans = ['$2008', '$5002', '$1000', '$2015', '$8123', '$3020', '$402', '$600', '$700', '$2500']; interval = Math.floor(Math.random() * (30000 - 8000 + 1) + 8000); var run = setInterval(request, interval); function request() { clearInterval(run); interval = Math.floor(Math.random() * (30000 - 8000 + 1) + 8000); var country = listCountries[Math.floor(Math.random() * listCountries.length)]; var plan = listPlans[Math.floor(Math.random() * listPlans.length)]; var msg = 'An investor from  <b>' + country + '</b> just Earned <strong href="javascript:void(0);" onclick="javascript:void(0);">' + plan + ' </strong>'; $(".mgm .txt").html(msg); $(".mgm").stop(true).fadeIn(2); window.setTimeout(function () { $(".mgm").stop(true).fadeOut(100); }, 8000); run = setInterval(request, interval); }</script>
        <script data-cfasync="false" src="cdn-cgi\scripts\5c5dd728\cloudflare-static\email-decode.min.js"></script>
        <script type="text/javascript">var listCountries = ['London', 'Carlifornia', 'Germany', 'France', 'Italy', 'USA', 'Australia', 'Lesotho', 'Canada', 'Argentina', 'Saudi Arabia', 'Mexico', 'Kenya', 'Maldives', 'Venezuela', 'Soweto', 'Sweden', 'India', 'South Africa', 'Italy', 'Pakistan', 'United Kingdom', 'South Africa', 'Greece', 'Cuba', 'South Africa', 'Delhi', 'Austria', 'South Africa', 'Panama', 'USA', 'South Africa', 'Netherlands', 'Switzerland', 'Belgium', 'Israel', 'Cyprus']; var listPlans = ['$2000', '$5000', '$1000', '$200', '$800', '$3000', '$400', '$600', '$700', '$2500']; interval = Math.floor(Math.random() * (30000 - 8000 + 1) + 8000); var run = setInterval(request, interval); function request() { clearInterval(run); interval = Math.floor(Math.random() * (30000 - 8000 + 1) + 8000); var country = listCountries[Math.floor(Math.random() * listCountries.length)]; var plan = listPlans[Math.floor(Math.random() * listPlans.length)]; var msg = 'An investor from  <b>' + country + '</b> just deposited <strong href="javascript:void(0);" onclick="javascript:void(0);">' + plan + ' </strong>'; $(".mgm .txt").html(msg); $(".mgm").stop(true).fadeIn(2); window.setTimeout(function () { $(".mgm").stop(true).fadeOut(100); }, 8000); run = setInterval(request, interval); }</script>
            <!-- features-area -->
            <section class="features-area-two pt-80">
                <div class="container">
                    <div class="features-item-wrap">
                        <div class="row justify-content-center">
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="features-item-two">
                                    <div class="features-icon-two">
                                        <i class="flaticon-profit"></i>
                                    </div>
                                    <div class="features-content-two">
                                        <h4 class="title">RISK MANAGEMENT</h4>
                                        <p>The Company continually identifies, assesses, and monitors each type of risk associated with its operations.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="features-item-two">
                                    <div class="features-icon-two">
                                        <i class="flaticon-investment"></i>
                                    </div>
                                    <div class="features-content-two">
                                        <h4 class="title">AUDIT & ACCOUNTING</h4>
                                        <p>Client funds are received into bank accounts separate from those used by the company.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="features-item-two">
                                    <div class="features-icon-two">
                                        <i class="flaticon-taxes"></i>
                                    </div>
                                    <div class="features-content-two">
                                        <h4 class="title">TRADING SUCCESS</h4>
                                        <p>Our community success speaks for itself. The markets have never been more exciting than they are now.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- features-area-end -->

            <!-- about-area -->
            <section class="about-area-three">
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-lg-6 col-md-9">
                            <div class="about-img-wrap-three">
                                <img src="assets/img/images/h2_about_img01.jpg" alt="" data-aos="fade-down-right" data-aos-delay="0">
                                <img src="assets/img/images/h2_about_img02.jpg" alt="" data-aos="fade-left" data-aos-delay="400">
                                <div class="experience-wrap" data-aos="fade-up" data-aos-delay="300">
                                    <h2 class="title">7 <span>Years</span></h2>
                                    <p>Of Experience in This Finance Advisory Company.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="about-content-three">
                                <div class="section-title-two mb-20 tg-heading-subheading animation-style3">
                                    <span class="sub-title">Get To know US</span>
                                    <h2 class="title tg-element-title">We Have An Eye For Profitable Invesments</h2>
                                </div>
                                <p class="info-one">We trade CFDs on FX, Stocks, Commodities, Crypto, NFTS, Digital assets, Indices, Options & Alternative investments
                                    <br />
                                    With advanced tools, through our experienced award winning professional traders.</p>
                                <div class="about-list-two">
                                    <ul class="list-wrap">
                                        <li><i class="fas fa-arrow-right"></i>Get personalised support</li>
                                        <li><i class="fas fa-arrow-right"></i>Uncompromising security</li>
                                        <li><i class="fas fa-arrow-right"></i>100% capital protection</li>
                                        <li><i class="fas fa-arrow-right"></i>No fees or hidden charges</li>
                                        <li><i class="fas fa-arrow-right"></i>Beating the stock market since 2016</li>
                                    </ul>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="about-shape-wrap-two">
                    <img src="assets/img/images/h2_about_shape01.png" alt="">
                    <img src="assets/img/images/h2_about_shape02.png" alt="">
                    <img src="assets/img/images/h2_about_shape03.png" alt="" data-aos="fade-left" data-aos-delay="500">
                </div>
            </section>
            <!-- about-area-end -->

            <!-- brand-area -->
            <div class="brand-aera-two pb-80">
                <div class="container">
                    <div class="row brand-active">
                        <div class="col-lg-12">
                            <div class="brand-item">
                                <img src="assets/img/brand/brand_img01.png" alt="">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="brand-item">
                                <img src="assets/img/brand/brand_img02.png" alt="">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="brand-item">
                                <img src="assets/img/brand/brand_img03.png" alt="">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="brand-item">
                                <img src="assets/img/brand/brand_img04.png" alt="">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="brand-item">
                                <img src="assets/img/brand/brand_img05.png" alt="">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="brand-item">
                                <img src="assets/img/brand/brand_img03.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- brand-area-end -->

            

            <!-- overview-area -->
            <section class="overview-area pt-120 pb-120">
                <div class="overview-shape" data-aos="fade-left" data-aos-delay="200" data-background="assets/img/images/overview_shape.png"></div>
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-lg-6 col-md-10">
                            <div class="overview-img-wrap">
                                <img src="assets/img/images/overview_img01.jpg" alt="">
                                <img src="assets/img/images/overview_img02.jpg" alt="" data-parallax='{"x" : 50 }'>
                                <img src="assets/img/images/overview_img_shape.png" alt="">
                                <div class="icon">
                                    <i class="flaticon-report-1"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="overview-content">
                                <div class="section-title-two mb-20 tg-heading-subheading animation-style3">
                                    <span class="sub-title">Investment Overview</span>
                                    <h2 class="title tg-element-title">INVEST WISELY TO GROW YOUR INVESTMENT PORTFOLIO</h2>
                                </div>
                                <div class="content-bottom">
                                    <ul class="list-wrap">
                                        <li>
                                            <div class="icon">
                                                <i class="flaticon-trophy"></i>
                                            </div>
                                            <div class="content">
                                                <h2 class="count"><span class="odometer" data-count="235"></span>+</h2>
                                                <p>Best Award</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="icon">
                                                <i class="flaticon-rating"></i>
                                            </div>
                                            <div class="content">
                                                <h2 class="count"><span class="odometer" data-count="98"></span>k</h2>
                                                <p>Happy Clients</p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- overview-area-end -->

            <!-- choose-area -->
            <section class="choose-area jarallax choose-bg" data-background="assets/img/bg/choose_bg.jpg">
                <div class="choose-shape">
                    <img src="assets/img/images/choose_shape.png" alt="" data-aos="fade-right" data-aos-delay="0">
                </div>
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12">
                            <div class="choose-content">
                                <center>
                                    <h3 style="color: white;">Blueprint Trade</h3>
                                    <video width="100%" height="315" controls>
                                        <source src="video.mp4" type="video/mp4"></video>
<br>
<br>
                                        <video width="100%" height="315" controls>
                                        <source src="video2.mp4" type="video/mp4"></video>
                                </center>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </section>
            <!-- choose-area-end --->


            <br><br><br><br><br>
            <!-- cta-area -->
            <section class="cta-area">
                <div class="container">
                    <div class="cta-inner-wrap" data-background="assets/img/bg/cta_bg.jpg">
                        <div class="row align-items-center">
                            <div class="col-lg-9">
                                <div class="cta-content">
                                    
                                    <h2 class="title">Ready to embark on your financial freedom acquisition? Let's get you started.</h2>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="cta-btn text-end">
                                    <a href="register.php" class="btn">Get Started</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- cta-area-end -->



            <!-- pricing-area -->
            <section class="pricing-area-two">
                <div class="pricing-shape">
                    <img src="assets/img/images/pricing_shape.png" alt="" data-aos="fade-left" data-aos-delay="200">
                </div>
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-lg-6">
                            <div class="section-title-two mb-50 tg-heading-subheading animation-style3">
                                <span class="sub-title">Flexible Investment Plans</span>
                                <h2 class="title tg-element-title">We’ve offered the best <br> investments for you</h2>
                            </div>
                        </div>
                       
                    </div>
                    <div class="pricing-item-wrap">
                        
                        <div class="row justify-content-center">
                            <div class="col-lg-6 col-md-6 col-sm-10">
                                <div class="pricing-box-two">
                                    <div class="pricing-head-two">
                                        <h4 class="title">Maximum Portfolio 1</h4>
                                        <div class="pricing-price-two">
                                            <h2 class="price monthly_price"><strong></strong>40%<span>After 5 Days</span></h2>
                                        </div>
                                    </div>
                                    <div class="pricing-bottom">
                                        <div class="pricing-list">
                                            <ul class="list-wrap">
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Minimum Deposit: $2000</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Maximum Deposit: $24,999</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">50% Deposit Bonus</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">10% Referral Commission</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">FX Trade</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Bonds</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Digital Assets</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Stock IPO</li>
                                            </ul>
                                        </div>
                                        <div class="pricing-btn-two">
                                            <a href="register.php" class="btn">Get The Plan Now</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-10">
                                <div class="pricing-box-two">
                                    <span class="popular">Popular</span>
                                    <div class="pricing-head-two">
                                        <h4 class="title">Maximum Portfolio 2</h4>
                                        <div class="pricing-price-two">
                                            <h2 class="price monthly_price"><strong></strong>100%<span>After 5 Days</span></h2>
                                        </div>
                                    </div>
                                    <div class="pricing-bottom">
                                        <div class="pricing-list">
                                            <ul class="list-wrap">
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Minimum Deposit: $25,000</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Maximum Deposit: Unlimited</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">100% Deposit Bonus</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">25% Referral Commission</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Agriculture</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Mining</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Real Estate</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">FX Trade</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Bonds</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Digital Assets</li>
                                                <li><img src="assets/img/icons/check_icon02.svg" alt="">Stock IPO</li>
                                            </ul>
                                        </div>
                                        <div class="pricing-btn-two">
                                            <a href="register.php" class="btn">Get The Plan Now</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </section>
            <!-- pricing-area-end -->

            <!-- blog-area -->
            <section class="blog-area-two blog-bg-two" data-background="assets/img/bg/h2_blog_bg.jpg">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <div class="section-title-two text-center mb-50 tg-heading-subheading animation-style3">
                                <span class="sub-title">News</span>
                                <h2 class="title tg-element-title">Checkout latest news
                                    <br>
                                    updates & articles</h2>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-lg-12 col-md-12 col-sm-10">
                            <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
    <div class="tradingview-widget-container__widget"></div>
    <div class="tradingview-widget-copyright"></div>
    <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-timeline.js" async>
    {
    "feedMode": "all_symbols",
    "colorTheme": "light",
    "isTransparent": false,
    "displayMode": "regular",
    "width": "100%",
    "height": 830,
    "locale": "en"
  }
    </script>
  </div>
  <!-- TradingView Widget END -->
                        </div>
                        

                    </div>
                </div>
            </section>
            <!-- blog-area-end -->

          

        </main>
        <!-- main-area-end -->


        <!-- footer-area -->
        <footer>
    <div class="footer-area footer-bg" data-background="assets/img/bg/footer_bg.jpg">
        <div class="container">
            <div class="footer-top">
                <div class="row">
                    <div class="col-lg-4 col-md-7">
                        <div class="footer-widget">
                            <h4 class="fw-title">Information</h4>
                            <div class="footer-info">
                                <ul class="list-wrap">
                                    <li>
                                        <div class="icon">
                                            <i class="flaticon-pin"></i>
                                        </div>
                                        <div class="content">
                                            <p>5357 Inglis St, Halifax, NS B3H 1J4, Canada</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="icon">
                                            <i class="flaticon-pin"></i>
                                        </div>
                                        <div class="content">
                                            <p>C/O Defries Weiss, 1 Bridge Lane, London, England, NW11 0EA</p>
                                        </div>
                                    </li>
                                    
                                    <li>
                                        <div class="icon">
                                            <i class="flaticon-mail"></i>
                                        </div>
                                        <div class="content">
                                            <p><a href="/cdn-cgi/l/email-protection#0b6a6f6662654b69677e6e7b7962657f267f796a6f6e7825686466"><span class="__cf_email__" data-cfemail="3e5f5a5357507e5c524b5b4e4c57504a134a4c5f5a5b4d105d5153">[email&#160;protected]</span></a></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-md-5 col-sm-6">
                        <div class="footer-widget">
                            <h4 class="fw-title">Quick Links</h4>
                            <div class="footer-link">
                                <ul class="list-wrap">
                                    <li><a href="index.php">Home</a></li>
                        <li><a href="faq.html">Frequently Asked Questions</a></li>
                        <li><a href="privacy.html">Privacy Policy</a></li>
                        <li><a href="contact-us.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-7">
                        <div class="footer-widget">
                            <h4 class="fw-title">Company Certificate</h4>
                            <div class="footer-newsletter">
                                <a href="cert.pdf"><button type="submit" class="btn btn-two">Canada Certificate</button></a>
                                <br>
                                <br>
                                <a href="ukcert.pdf"><button type="submit" class="btn btn-two">UK Certificate</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="left-sider">
                            <div class="f-logo">
                                <a href="index.php"><img src="assets/img/logo/w_logo.png" alt=""></a>
                            </div>
                            <div class="copyright-text">
                                <p>Copyright © Blueprint Trade | All Right Reserved</p>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
</footer>
        <!-- footer-area-end -->


        <!-- JS here -->
        <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <script src="assets/js/jquery.odometer.min.js"></script>
        <script src="assets/js/jquery.appear.js"></script>
        <script src="assets/js/gsap.js"></script>
        <script src="assets/js/ScrollTrigger.js"></script>
        <script src="assets/js/SplitText.js"></script>
        <script src="assets/js/gsap-animation.js"></script>
        <script src="assets/js/jarallax.min.js"></script>
        <script src="assets/js/jquery.parallaxScroll.min.js"></script>
        <script src="assets/js/particles.min.js"></script>
        <script src="assets/js/jquery.easypiechart.min.js"></script>
        <script src="assets/js/jquery.inview.min.js"></script>
        <script src="assets/js/swiper-bundle.min.js"></script>
        <script src="assets/js/slick.min.js"></script>
        <script src="assets/js/ajax-form.js"></script>
        <script src="assets/js/aos.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/main.js"></script>
    </body>

<!-- Mirrored from themeadapt.com/tf/gerow/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 02 Jul 2023 14:10:53 GMT -->
</html>
