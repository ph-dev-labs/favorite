<!doctype html>
<html class="no-js" lang="en">
    
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Contact Us</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
        <!-- Place favicon.ico in the root directory -->

        <!-- CSS here -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" href="assets/css/magnific-popup.css">
        <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
        <link rel="stylesheet" href="assets/css/flaticon.css">
        <link rel="stylesheet" href="assets/css/odometer.css">
        <link rel="stylesheet" href="assets/css/jarallax.css">
        <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
        <link rel="stylesheet" href="assets/css/slick.css">
        <link rel="stylesheet" href="assets/css/aos.css">
        <link rel="stylesheet" href="assets/css/default.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/responsive.css">
    <script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '811844c3d2ec284467afb513e84cfc9c30c9830c';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>
</head>
    <body>

        <!-- preloader -->
        <div id="preloader">
            <div id="loading-center">
                <div class="loader">
                    <div class="loader-outter"></div>
                    <div class="loader-inner"></div>
                </div>
            </div>
        </div>
        <!-- preloader-end -->

		<!-- Scroll-top -->
        <button class="scroll-top scroll-to-target" data-target="html">
            <i class="fas fa-angle-up"></i>
        </button>
        <!-- Scroll-top-end-->

        <!-- header-area -->
        <div id="header-fixed-height"></div>
        <header class="header-style-six">
            <div class="heder-top-wrap">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-7">
                            <div class="header-top-left">
                                <ul class="list-wrap">
                                    <li><i class="flaticon-location"></i>5357 Inglis St, Halifax, NS B3H 1J4, Canada</li>
                                    <li><i class="flaticon-location"></i>C/O Defries Weiss, 1 Bridge Lane, London, England, NW11 0EA</li>
                                    <li><i class="flaticon-mail"></i><a href="/cdn-cgi/l/email-protection#e48580898d8aa48688918194968d8a90c9909685808197ca878b89"><span class="__cf_email__" data-cfemail="553431383c3b153739203025273c3b21782127343130267b363a38">[email&#160;protected]</span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="header-top-right">
                                <div id="google_translate_element"></div>
                        <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
                        <script type="text/javascript">
                            function googleTranslateElementInit() {
                                new google.translate.TranslateElement({ pageLanguage: 'en' }, 'google_translate_element');
                            }
                                </script>
                        <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="sticky-header" class="menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="mobile-nav-toggler"><i class="fas fa-bars"></i></div>
                            <div class="menu-wrap">
                                <nav class="menu-nav">
                                    <div class="logo">
                                        <a href="index.php"><img src="assets/img/logo/logo.png" alt="Logo"></a>
                                    </div>
                                    <div class="navbar-wrap main-menu d-none d-lg-flex">
                                        <ul class="navigation">
                                            <li><a href="index.php">Home</a></li>
                        
                        <li><a href="faq.html">FAQs</a></li>
                        <li><a href="privacy.html">Privacy Policy</a></li>
                        <li class="active"><a href="contact.php">Contact</a></li>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="register.php">Register</a></li>
                                        </ul>
                                    </div>
                                    
                                </nav>
                            </div>

                            <!-- Mobile Menu  -->
                            <div class="mobile-menu">
                                <nav class="menu-box">
                                    <div class="close-btn"><i class="fas fa-times"></i></div>
                                    <div class="nav-logo">
                                        <a href="index.php"><img src="assets/img/logo/logo.png" alt="Logo"></a>
                                    </div>
                                    
                                    <div class="menu-outer">
                                        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                                    </div>
                                    
                                </nav>
                            </div>
                            <div class="menu-backdrop"></div>
                            <!-- End Mobile Menu -->

                        </div>
                    </div>
                </div>
            </div>

            <!-- header-search -->
            <div class="search-popup-wrap" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="search-close">
                    <span><i class="fas fa-times"></i></span>
                </div>
                <div class="search-wrap text-center">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <h2 class="title">... Search Here ...</h2>
                                <div class="search-form">
                                    <form action="#">
                                        <input type="text" name="search" placeholder="Type keywords here">
                                        <button class="search-btn"><i class="fas fa-search"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-search-end -->

        </header>
        <!-- header-area-end -->


        <!-- main-area -->
        <main class="fix">

            <!-- breadcrumb-area -->
            <section class="breadcrumb-area breadcrumb-bg" data-background="assets/img/bg/breadcrumb_bg.jpg">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="breadcrumb-content">
                                <h2 class="title">Contact Us</h2>
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Contact</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="breadcrumb-shape-wrap">
                    <img src="assets/img/images/breadcrumb_shape01.png" alt="">
                    <img src="assets/img/images/breadcrumb_shape02.png" alt="">
                </div>
            </section>
            <!-- breadcrumb-area-end -->

            <!-- contact-area -->
            <section class="contact-area contact-bg" data-background="assets/img/bg/contact_bg.jpg">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-5">
                            <div class="contact-content">
                                <div class="section-title mb-30 tg-heading-subheading animation-style2">
                                    <span class="sub-title tg-element-title">GET IN TOUCH</span>
                                    <h2 class="title tg-element-title">We Are Connected To Help You Grow!</h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="contact-form">
                                <form action="#">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-grp">
                                                <input type="text" placeholder="Name *">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-grp">
                                                <input type="email" placeholder="E-mail *">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-grp">
                                                <input type="number" placeholder="Phone *">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-grp">
                                                <input type="text" placeholder="Subject *">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-grp">
                                                <textarea placeholder="Comments *"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit">Submit Now</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="contact-shape">
                    <img src="assets/img/images/contact_shape.png" alt="">
                </div>
            </section>
            <!-- contact-area-end -->


        </main>
        <!-- main-area-end -->


        <!-- footer-area -->
        <footer>
            <div class="footer-area footer-bg" data-background="assets/img/bg/footer_bg.jpg">
                <div class="container">
                    <div class="footer-top">
                        <div class="row">
                            <div class="col-lg-4 col-md-7">
                                <div class="footer-widget">
                                    <h4 class="fw-title">Information</h4>
                                    <div class="footer-info">
                                        <ul class="list-wrap">
                                            <li>
                                                <div class="icon">
                                                    <i class="flaticon-pin"></i>
                                                </div>
                                                <div class="content">
                                                    <p>5357 Inglis St, Halifax, NS B3H 1J4, Canada</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="icon">
                                                    <i class="flaticon-pin"></i>
                                                </div>
                                                <div class="content">
                                                    <p>C/O Defries Weiss, 1 Bridge Lane, London, England, NW11 0EA</p>
                                                </div>
                                            </li>
                                            
                                            <li>
                                                <div class="icon">
                                                    <i class="flaticon-mail"></i>
                                                </div>
                                                <div class="content">
                                                    <p><a href="/cdn-cgi/l/email-protection#79181d141017391b150c1c090b10170d540d0b181d1c0a571a1614"><span class="__cf_email__" data-cfemail="e283868f8b8ca2808e978792908b8c96cf969083868791cc818d8f">[email&#160;protected]</span></a></p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-4 col-md-5 col-sm-6">
                                <div class="footer-widget">
                                    <h4 class="fw-title">Quick Links</h4>
                                    <div class="footer-link">
                                        <ul class="list-wrap">
                                            <li><a href="index.php">Home</a></li>
								<li><a href="faq.html">Frequently Asked Questions</a></li>
								<li><a href="privacy.html">Privacy Policy</a></li>
								<li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-7">
                                <div class="footer-widget">
                                    <h4 class="fw-title">Company Certificate</h4>
                                    <div class="footer-newsletter">
                                        <a href="cert.pdf"><button type="submit" class="btn btn-two">Canada Certificate</button></a>
                                        <br>
                                        <br>
                                        <a href="ukcert.pdf"><button type="submit" class="btn btn-two">UK Certificate</button></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="footer-bottom">
                        <div class="row align-items-center">
                            <div class="col-md-12">
                                <div class="left-sider">
                                    <div class="f-logo">
                                        <a href="index.php"><img src="assets/img/logo/w_logo.png" alt=""></a>
                                    </div>
                                    <div class="copyright-text">
                                        <p>Copyright © Blueprint Trade | All Right Reserved</p>
                                    </div>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer-area-end -->


        <!-- JS here -->
        <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <script src="assets/js/jquery.odometer.min.js"></script>
        <script src="assets/js/jquery.appear.js"></script>
        <script src="assets/js/gsap.js"></script>
        <script src="assets/js/ScrollTrigger.js"></script>
        <script src="assets/js/SplitText.js"></script>
        <script src="assets/js/gsap-animation.js"></script>
        <script src="assets/js/jarallax.min.js"></script>
        <script src="assets/js/jquery.parallaxScroll.min.js"></script>
        <script src="assets/js/particles.min.js"></script>
        <script src="assets/js/jquery.easypiechart.min.js"></script>
        <script src="assets/js/jquery.inview.min.js"></script>
        <script src="assets/js/swiper-bundle.min.js"></script>
        <script src="assets/js/slick.min.js"></script>
        <script src="assets/js/ajax-form.js"></script>
        <script src="assets/js/aos.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/main.js"></script>
    </body>

<!-- Mirrored from themeadapt.com/tf/gerow/contact.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 02 Jul 2023 14:11:08 GMT -->
</html>
