<script type="text/javascript">
         window.location.href = "contact.php";
         </script>